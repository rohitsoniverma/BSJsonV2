package com.appexpertstudio.bsjson;

import android.util.Base64;

public class Helpers {
    public static String toBase64(String input) {
        return input;
    }

}
